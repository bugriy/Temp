﻿#Host Status check Monitor


function Log-Event ($Level, $Message)
		{
		$Message = "`n" + $Message
		if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
		{
		$api.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
			Write-Host $Message -ForegroundColor Red
		}
		}


$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.VMWareHostStatusCheckMonitor.ps1';
$SCRIPT_EVENT_ID = 8824;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;


$api = New-Object -comObject 'MOM.ScriptAPI'

Log-Event $INFO_ "Script started. v1.3"


#$setupKey = Get-Item -Path "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Setup" 
#$installDirectory = $setupKey.GetValue("InstallDirectory") | Split-Path 
#$psmPath = $installdirectory + "\Powershell\OperationsManager\OperationsManager.psm1" 
#Import-Module $psmPath

$Error.Clear()
try{
$vCenters = Get-SCOMClass -name "MS.VMware.Class.vCenter" | get-SCOMmonitoringobject
}
catch
{
$ErrorText = $_.Exception.Message
Log-Event $WARNING_ "Can't get vCenter class instances from SCOM. Error: $ErrorText"
	exit
}





#$ErrorTextModule=""
#$ErrorTextPSSnapin=""

#$error.Clear()
#try{Import-Module -Name VMware.VimAutomation.Core -ErrorAction Stop}
#catch
#{$ErrorTextModule = $_.Exception}

#$error.Clear()
#try
#{Add-PSSnapin -PassThru VMware.VimAutomation.Core}
#catch
#{$ErrorTextPSSnapin = $_.Exception}


#if (($ErrorTextModule -ne "") -and ($ErrorTextPSSnapin -ne ""))
#{
#Log-Event $ERROR_ "Can't use PowerCLI. Module load error: $ErrorTextModule, SnapIn load error: $ErrorTextPSSnapin"
#exit
#}




Foreach ($vCenter in $vCenters)
{
	$vCenterServerName = $vCenter.Name

Try 
	{
	#Log-Event $INFO_ "Connect to vCenterServer, Name: $vCenterServerName"
	$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#	$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
	}

Catch {

	$ErrorText = $_.Exception.Message
	Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"
}

$SessionID = $connection.SessionID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Start-Sleep -s 10
		
		try{
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
		}
		catch
		{
		$ErrorText = $_.Exception.Message
	    Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"
		}


#		$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
	}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID  + $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = '$SessionID'. Exit Script"
		Exit
	}

$Global:GlobalID = $SessionID  + $vCenterServerName

Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID - $SessionID"


Try {
$VMhosts = Get-View -Server $connection -ViewType HostSystem -Property Name, OverallStatus | Select Name, OverallStatus
}

Catch {
	$ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't execute Get-View -Server Connection -ViewType HostSystem -Property Name, OverallStatus | Select Name, OverallStatus. $ErrorText"
	exit
}

foreach ($VMHost in $VMHosts)

{	

	$HostName = [string]$VMHost.Name
	$HostStatus = [string]$VMHost.OverallStatus

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('HostName', $HostName)
	$bag.AddValue('HostStatus', $HostStatus)
	$bag
}

 Try {Disconnect-VIServer -Server $connection -Confirm:$false}
 
	Catch {
		$ErrorText = $_.Exception.Message
	 Log-Event $ERROR_ "Can't disconnect from vCenter. $ErrorText"
 }


}


Log-Event $INFO_ "Script finished."






