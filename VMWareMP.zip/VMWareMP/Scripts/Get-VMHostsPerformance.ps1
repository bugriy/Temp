function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$api.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
	}
}

$api = new-object -comObject 'MOM.ScriptAPI'

$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.VMware.Get-HostPerformance.ps1';
$SCRIPT_EVENT_ID = 8896;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;

Log-Event $INFO_ "Script started. v1.3"


try{
$vCenters = Get-SCOMClass -name "MS.VMware.Class.vCenter" | get-SCOMmonitoringobject
}
catch
{
$ErrorText = $_.Exception.Message
Log-Event $WARNING_ "Can't get vCenter class instances from SCOM. Error: $ErrorText"
}


$VMList = "Not Applicable"
$VMHosts = @()
$VMHostsArray = @{}

Foreach ($vCenter in $vCenters)
{
	$vCenterServerName = $vCenter.Name


	$NetTest = (test-netconnection -computer $vCenter.Name -Port 443).TcpTestSucceeded

	Log-Event $INFO_ "test-netconnection $($vCenter.Name) result: $NetTest"


Try 
{
	#Log-Event $INFO_ "Connect to vCenterServer, Name: $vCenterServerName"
	$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#	$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
}

Catch {
	$ErrorText = $_.Exception.Message
	Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"

}

$SessionID = $connection.SessionID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Start-Sleep -s 10

		try{
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#		$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
		}
		catch
		{
		$ErrorText = $_.Exception.Message
		Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"
		}
		
		}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = '$SessionID'. Exit Script"
		
	}

$Global:GlobalID = $SessionID + $vCenterServerName

Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID - $SessionID"

Try		{$VMhostsList = Get-View -ViewType HostSystem -Property Summary, Name, VM | Select Summary, Name, VM}
Catch
{
	$ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get HostSystem list view from $vCenterServerName. $ErrorText"
	exit
}

Try		{
	$vms_view = Get-View -ViewType VirtualMachine -Property Summary, Name}
Catch
{
	$ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get VirtualMachine list view from $vCenterServerName. $ErrorText"
exit
}

ForEach ($VMhost in $VMhostsList)
{
	$hostBaloonMem = 0
	$HostSwapMem = 0

	$SwappedMemoryVMList = ""
	$BalloonedMemoryVMList = ""

	foreach ($hostvm in $vmhost.vm)
	{
		foreach ($vm in $vms_view)        
		{		
			if ($vm.MoRef.Value -eq $hostvm.Value)
			{          
				$hostBaloonMem +=  $vm.Summary.QuickStats.BalloonedMemory
				$HostSwapMem +=  $vm.Summary.QuickStats.SwappedMemory

				if ($vm.Summary.QuickStats.SwappedMemory -gt 0)
				{$SwappedMemoryVMList += $vm.Name + ': '+ $vm.Summary.QuickStats.SwappedMemory +'M, '}

				if ($vm.Summary.QuickStats.BalloonedMemory -gt 0)
				{$BalloonedMemoryVMList += $vm.Name + ': '+ $vm.Summary.QuickStats.BalloonedMemory +'M, '}
			}        
		}
	}
	
	if ($BalloonedMemoryVMList -ne "")
	{
		$BalloonedMemoryVMList = $BalloonedMemoryVMList.Trim()
		$BalloonedMemoryVMList = $BalloonedMemoryVMList -replace ".$"				  
	}
	else
	{
		$BalloonedMemoryVMList = "Not Found"
	}

	if ($SwappedMemoryVMList -ne "")
	{
		$SwappedMemoryVMList = $SwappedMemoryVMList.Trim()
		$SwappedMemoryVMList = $SwappedMemoryVMList -replace ".$"				 
	}
	else
	{
		$SwappedMemoryVMList = "Not Found"
	}

	$CPU_UsageMHz	= $VMhost.Summary.QuickStats.OverallCpuUsage
	$CPU_MaxMHz		= $VMhost.Summary.Hardware.CpuMhz * $VMhost.Summary.Hardware.NumCpuCores
	$CPU_FreeMHz	= $CPU_MaxMHz - $CPU_UsageMHz
	$CPU_Percent	= [math]::Round($CPU_UsageMHz*100/$CPU_MaxMHz)

	$MEM_UsageMB	= $VMhost.Summary.QuickStats.OverallMemoryUsage
	$MEM_MaxMB		= [math]::Round($VMhost.Summary.Hardware.MemorySize/1048576)
	$MEM_FreeMB		= $MEM_MaxMB - $MEM_UsageMB
	$MEM_Percent	= [math]::Round($MEM_UsageMB*100/$MEM_MaxMB)

	$HostName = $VMhost.Name
	$VMHosts += $HostName
	$VMHostsArray[$HostName] = @{}
	$VMHostsArray[$HostName]["MEM"] = $MEM_Percent 
	$VMHostsArray[$HostName]["CPU"] = $CPU_Percent
	$VMHostsArray[$HostName]["BMEM"] = $hostBaloonMem
	$VMHostsArray[$HostName]["BMEMList"] = $BalloonedMemoryVMList
	$VMHostsArray[$HostName]["SMEM"] = $HostSwapMem
	$VMHostsArray[$HostName]["SMEMList"] = $SwappedMemoryVMList
}

	Try		{
		Disconnect-VIServer -Server $connection -Confirm:$false
	}
	Catch	{
		$ErrorText = $_.Exception.Message
		Log-Event $ERROR_ "Can't disconnect from vCenter. $ErrorText"
	}
	
}

$j = 0
While ($j -ne $VMHosts.length ) 
{
	$bag = $api.CreatePropertyBag()
	$bag.AddValue('HostName',$VMHosts[$j])
	$bag.AddValue('CounterName',"CPU Usage Percent")
	$bag.AddValue('VMList',$VMList)
	$bag.AddValue('Value',$VMHostsArray[$VMHosts[$j]]["CPU"])                 
	$bag

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('HostName',$VMHosts[$j])
	$bag.AddValue('CounterName',"Memory Usage Percent")
	$bag.AddValue('VMList',$VMList)        
	$bag.AddValue('Value',$VMHostsArray[$VMHosts[$j]]["MEM"] )
	$bag

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('HostName',$VMHosts[$j])
	$bag.AddValue('CounterName',"Host VMs Summary Ballooned Memory")          
	$bag.AddValue('Value',$VMHostsArray[$VMHosts[$j]]["BMEM"])
	$bag.AddValue('VMList',$VMHostsArray[$VMHosts[$j]]["BMEMList"] )
	$bag

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('HostName',$VMHosts[$j])
	$bag.AddValue('CounterName',"Host VMs Summary Swapped Memory")          
	$bag.AddValue('Value',$VMHostsArray[$VMHosts[$j]]["SMEM"])
	$bag.AddValue('VMList',$VMHostsArray[$VMHosts[$j]]["SMEMList"])
	$bag
			
	$j = $j + 1
}

Log-Event $INFO_ "Script finished."

