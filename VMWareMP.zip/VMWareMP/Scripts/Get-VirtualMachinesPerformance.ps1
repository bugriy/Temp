﻿function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$api.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
	}
}

$start = Get-Date
$api = new-object -comObject 'MOM.ScriptAPI'

$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.VMware.Get-VirtualMachinePerformance.ps1';
$SCRIPT_EVENT_ID = 8825;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;

$ErrorTextModule=""
$ErrorTextPSSnapin=""


Log-Event $INFO_ "Script started. v1.3"


$Error.Clear()
try{
$vCenters = Get-SCOMClass -name "MS.VMware.Class.vCenter" | get-SCOMmonitoringobject
}
catch
{
$ErrorText = $_.Exception.Message
Log-Event $WARNING_ "Can't get vCenter class instances from SCOM. Error: $ErrorText"
}



$VMs = @()
$VMsArray = @{}



Foreach ($vCenter in $vCenters)
{
	$vCenterServerName = $vCenter.Name
$Error.Clear()
Try 
{
	#Log-Event $INFO_ "Connect to vCenterServer, Name: $vCenterServerName"
	$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#	$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose 
}

Catch {Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $($_.Exception.Message)"}

$SessionID = $connection.SessionID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Start-Sleep -s 10
		$connection = Connect-VIServer -Server $vCenterServerName  -Force:$true -NotDefault -Verbose -ErrorAction Stop
#		$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose 
	}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = '$SessionID'. Exit Script"
		Exit
	}

$Global:GlobalID = $SessionID + $vCenterServerName

Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID - $SessionID"

$Error.Clear()

Try		{$vms_view = Get-View -Server $connection -ViewType VirtualMachine -Property Summary, Guest, Name, Overallstatus, ConfigStatus, GuestHeartbeatStatus}
Catch   {Log-Event $ERROR_ "Can't get VirtualMachine list view from $vCenterServerName. $($_.Exception.Message)" }

ForEach ($VMobject in $vms_view)
{	
	$VMName = $VMobject.Name
	$ToolsRunningStatus = ($VMobject.guest.ToolsRunningStatus) -replace "guestTools",""
	$ToolsVersionStatus = ($VMobject.guest.ToolsVersionStatus) -replace "guestTools",""

	$powerstate = $VMobject.summary.runtime.powerstate

	$VMID = ("vC-"+$vCenter+"/VM-"+$VMobject.Name)
	
	$VMs += $VMID
	$VMsArray[$VMID] = @{}
	$VMsArray[$VMID]["VMName"] = $VMobject.MoRef.Value 
	$VMsArray[$VMID]["ToolsRunningStatus"] = $ToolsRunningStatus
	$VMsArray[$VMID]["ToolsVersionStatus"] = $ToolsVersionStatus
	$VMsArray[$VMID]["PowerState"] = $VMobject.summary.runtime.powerstate
	$VMsArray[$VMID]["OverallStatus"] = $VMobject.OverallStatus
	$VMsArray[$VMID]["GuestHeartbeatStatus"] = $VMobject.GuestHeartbeatStatus
	$VMsArray[$VMID]["ConfigStatus"] = $VMobject.ConfigStatus
				
}

$Error.Clear()
Try		{Disconnect-VIServer -Server $connection -Confirm:$false}
Catch   {Log-Event $ERROR_ "Can't disconnect from vCenter. $($_.Exception.Message)"}
}

$j = 0

Log-Event $INFO_ "VMs to add: $($VMs.length)"

While ($j -ne $VMs.length ) 
{

	#$VMsArray[$VMs[$j]]["ToolsRunningStatus"]
	#Good = "Running" или "ExecutingScripts"
	#Bad = всё остальное

	if (($VMsArray[$VMs[$j]]["ToolsRunningStatus"] -eq "Running") -or ($VMsArray[$VMs[$j]]["ToolsRunningStatus"] -eq "ExecutingScripts")) 
	{$Value="Good"}
	else
	{$Value="Bad"}


	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"ToolsRunningStatus")
	$bag.AddValue('Value',$Value)
	$bag.AddValue('Status',$VMsArray[$VMs[$j]]["ToolsRunningStatus"])
	$bag

	#$VMsArray[$VMs[$j]]["ToolsVersionStatus"]
	#Good = "Current" or "Unmanaged"
	#Bad - всё остальное

	if (($VMsArray[$VMs[$j]]["ToolsVersionStatus"] -eq "Current") -or ($VMsArray[$VMs[$j]]["ToolsVersionStatus"] -eq "Unmanaged")) 
	{$Value="Good"}
	else
	{$Value="Bad"}


	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"ToolsVersionStatus")          
	$bag.AddValue('Value',$Value)
	$bag.AddValue('Status',$VMsArray[$VMs[$j]]["ToolsVersionStatus"])
	$bag

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"PowerState")          
	$bag.AddValue('Value',$VMsArray[$VMs[$j]]["PowerState"])
	$bag	

	Switch ($VMsArray[$VMs[$j]]["OverallStatus"])
	{
	"gray" {$OverallStatus ="Yellow"}
	"green" {$OverallStatus ="Green"}
	default {$OverallStatus ="Red"}
	}

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"OverallStatus")          
	$bag.AddValue('Value',[string]$VMsArray[$VMs[$j]]["OverallStatus"])
	$bag.AddValue('Status',$OverallStatus)
	$bag	

	Switch ($VMsArray[$VMs[$j]]["GuestHeartbeatStatus"])
	{
	"gray" {$GuestHeartbeatStatus ="Yellow"}
	"green" {$GuestHeartbeatStatus ="Green"}
	default {$GuestHeartbeatStatus ="Red"}
	}

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"GuestHeartbeatStatus")          
	$bag.AddValue('Value',[string]$VMsArray[$VMs[$j]]["GuestHeartbeatStatus"])
	$bag.AddValue('Status',$GuestHeartbeatStatus)
	$bag	

	Switch ($VMsArray[$VMs[$j]]["ConfigStatus"])
	{
	"gray" {$ConfigStatus ="Yellow"}
	"green" {$ConfigStatus ="Green"}
	default {$ConfigStatus ="Red"}
	}

	$bag = $api.CreatePropertyBag()
	$bag.AddValue('VMID',$VMsArray[$VMs[$j]]["VMName"])
	$bag.AddValue('ParameterName',"ConfigStatus")          
	$bag.AddValue('Value',[string]$VMsArray[$VMs[$j]]["ConfigStatus"])
	$bag.AddValue('Status',$ConfigStatus)
	$bag	

	Log-Event $INFO_ "VM: $($VMsArray[$VMs[$j]]["VMName"]), ConfigStatus=$ConfigStatus ($($VMsArray[$VMs[$j]]["ConfigStatus"])), GuestHeartbeatStatus=$GuestHeartbeatStatus ($($VMsArray[$VMs[$j]]["GuestHeartbeatStatus"])), OverallStatus=$OverallStatus ($($VMsArray[$VMs[$j]]["OverallStatus"]))" 
			
	$j += 1
}

$end = Get-Date
$TotalTM = ($end - $start).TotalSeconds

Log-Event $INFO_ "Script Finished. Total Runtime: $TotalTM. VM's checked: $j" 

 remove-variable $connection
#[System.GC]::Collect() 


