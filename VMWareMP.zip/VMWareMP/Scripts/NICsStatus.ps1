﻿
function Log-Event ($Level, $Message)
				{
				$Message = "`n" + $Message
				if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
				{
				$api.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
				}
				}



$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.Get.NICs.Status.ps1';
$SCRIPT_EVENT_ID = 8855;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;


$api = New-Object -comObject 'MOM.ScriptAPI'


$StartTime = Get-Date
#Set variable to be used in logging events
$whoami = whoami

Log-Event $INFO_ "Script started. v1.3. User: $whoami"

try{
$vCenters = Get-SCOMClass -name "MS.VMware.Class.vCenter" | get-SCOMmonitoringobject
}
catch
{
$ErrorText = $_.Exception.Message
Log-Event $WARNING_ "Can't get vCenter class instances from SCOM. Error: $ErrorText"
}



Foreach ($vCenter in $vCenters)
{
	$vCenterServerName = $vCenter.Name

Try 
	{
	$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose  -ErrorAction Stop
	}

Catch {
	$ErrorText = $_.Exception.Message
   Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"}

$SessionID = $connection.SessionID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName ) -eq $GlobalID) )
	{
		Start-Sleep -s 10
		try{
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
			}
		catch
		{
		$ErrorText = $_.Exception.Message
	    Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"
		}


	}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID+ $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = '$SessionID'. Exit Script"
		Exit
	}

$Global:GlobalID = $SessionID + $vCenterServerName

#Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID - $SessionID"
	


Try		{
	$VMHosts = Get-VMHost -Server $Connection
}
Catch
{  $ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get Servers list view from $vCenterServerName. Error: $ErrorText"
}


foreach ($VMHost in $VMHosts)
{
	

	try {
	$esxcli = Get-EsxCli -Server $connection -VMHost $VMHost.Name -V2 -ErrorAction Stop -WarningAction Continue
	
		}
	catch
	{
	$ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't connect to server $($VMHost.Name) via session $SessionID using Get-EsxCli from $vCenterServerName. Error: $ErrorText"
	}

	if ($esxcli.VMHost.Name -ne $VMHost.Name) 
	{
	Log-Event $ERROR_ "esxcli.VMHost.Name=$($esxcli.VMHost.Name), real host name=$($VMHost.Name). looks like esxcli not initialized."
	}
	else
	{
	#Log-Event $INFO_ "Succesfully connected to $($esxcli.VMHost.Name). esxcli initialized."
	}


	try{
	$NICsList = $esxcli.network.nic.list.Invoke() 
	}
	catch
	{
	$ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get NIC list from server $($VMHost.Name) using network.nic.list.Invoke(). vCenter: $vCenterServerName. Error: $ErrorText"
	}



	
	Log-Event $INFO_ "Found $($NICsList.count) NICs for host $($VMhost.Name)"

    $HostId = ($VMHost.id -split "HostSystem-")[1]

	foreach ($NIC in $NICsList)

			{$NIC

				Switch ($NIC.link)
				{
					 "UP" {  $Status="Green"}
					"Down" {$Status="Red"}
					default {$Status="Yellow"}			
				}


      #  Log-Event $INFO_ "adding 'NICName'=$($NIC.Name), 'HostId'=$($HostId), 'CounterName'=Status, 'Value'=$Status"
    
      $bag = $api.CreatePropertyBag()
      $bag.AddValue('NICName', $NIC.Name)
	  $bag.AddValue('HostId', $HostId)	 
      $bag.AddValue('CounterName',"Status")
      $bag.AddValue('Status',[string]$NIC.link)
      $bag.AddValue('Value',$Status)               
      $bag 

			}

}


$Error.Clear()
 Try {

	 Disconnect-VIServer -Server $connection -Confirm:$false
 
 }
 Catch {
	 $ErrorText = $_.Exception.Message
	 Log-Event $ERROR_ "Can't disconnect from vCenter. $ErrorText"
 }


	}



	$EndTime = Get-Date
    $ScriptTime = ($EndTime - $StartTime).TotalSeconds

	Log-Event $INFO_ "Script finished. Runtime: $ScriptTime seconds."