﻿	
param($HBAtype)

function Log-Event ($Level, $Message)
				{
				$Message = "`n" + $Message
				if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
				{
				$api.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
				}
				}



$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.Get.HBA.Status.ps1';
$SCRIPT_EVENT_ID = 8845;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;


$api = New-Object -comObject 'MOM.ScriptAPI'

Log-Event $INFO_ "Script started. v1.3. Parameter=$HBAtype"



try{
$vCenters = Get-SCOMClass -name "MS.VMware.Class.vCenter" | get-SCOMmonitoringobject
}
catch
{
$ErrorText = $_.Exception.Message
Log-Event $WARNING_ "Can't get vCenter class instances from SCOM. Error: $ErrorText"
}




Foreach ($vCenter in $vCenters)
{
	$vCenterServerName = $vCenter.Name

Try 
	{
	#Log-Event $INFO_ "Connect to vCenterServer, Name: $vCenterServerName"
	$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#	$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose 
	}

Catch {
	$ErrorText = $_.Exception.Message
    Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText. Will try one more time after 10 sec."
}

$SessionID = $connection.SessionID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Start-Sleep -s 10

		try{
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
			}
		catch
		{
		$ErrorText = $_.Exception.Message
		Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $ErrorText"
		}
#		$connection = Connect-VIServer -Server $vCenterServerName -User "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$" -Password "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$" -Force:$true -NotDefault -Verbose 
	}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = $SessionID. Exit Script"
		Exit
	}

$Global:GlobalID = $SessionID + $vCenterServerName

Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID - $SessionID"


$Error.Clear()
Try		{
	$HBAs = Get-VMHostHba -Server $Connection -type $HBAtype
}
Catch
{  $ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get HBAs list view from $vCenterServerName. Error: $ErrorText"
}

    foreach ($HBA in $HBAs)
    {
    $HBA.Name
    $HBA.VMHostId
    $HBA.Status

    if (($HBA.Status -ne "Online") -and ($HBA.Status -ne "Unknown")){$Status = "BAD"}
    else
    {$Status = "GOOD"}

    Log-Event $INFO_ "'HBAName'=$($HBA.Name), 'HostId'=$($HBA.VMHostId), 'CounterName'=Status, 'Value'=$Status"
    
      $bag = $api.CreatePropertyBag()
      $bag.AddValue('HBAName', $HBA.Name)
	  $bag.AddValue('HostId', $HBA.VMHostId)	 
      $bag.AddValue('CounterName',"Status")
      $bag.AddValue('Status',$HBA.Status)
      $bag.AddValue('Value',$Status)               
      $bag    
    
    }

 Try {
	 Disconnect-VIServer -Server $connection -Confirm:$false
 }
 Catch {
	 $ErrorText = $_.Exception.Message
	 Log-Event $ERROR_ "Can't disconnect from vCenter. $ErrorText"
 }


	}


	Log-Event $INFO_ "Script finished."