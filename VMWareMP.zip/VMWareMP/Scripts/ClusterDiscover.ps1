﻿param($sourceId, $managedEntityId, $vCenterServerName)

Function Log-Event ($Level, $Message)
{
		$Message = "`n" + $Message
		if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
		{
		$API.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
		}
}


$WriteToEventLog = 1;

#Constants used for event logging
$SCRIPT_NAME = 'MS.VMWareClustersDiscovery.ps1';
$SCRIPT_EVENT_ID = 9988;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;

#$UserCLI = "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/UserName$"
#$PasswordCLI = "$RunAs[Name="MS.VMWareMonitoring.RunAsProfile"]/Password$"

$API = New-Object -comObject 'MOM.ScriptAPI'

$whoami = whoami

Log-Event $INFO_ "Script started, v1.0, vCenterServerName=$vCenterServerName, username = $whoami"



"Try to connect"

Try 
	{
	    Log-Event $INFO_ "Try to connect to vCenterServer, Name: $vCenterServerName"
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
#		$connection = Connect-VIServer -Server $vCenterServerName -User $UserCLI -Password $PasswordCLI -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue

	}

 Catch {
 	     Log-Event $WARNING_ "Can't connect to vCenterServer, Name: $vCenterServerName. $_"
	   }



$SessionID = $connection.SessionID

$SessionID

$Global:GlobalID

If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID + $vCenterServerName) -eq $GlobalID) )
	{
		Start-Sleep -s 10
		$connection = Connect-VIServer -Server $vCenterServerName -Force:$true -NotDefault -Verbose -ErrorAction Stop
#		$connection = Connect-VIServer -Server $vCenterServerName -User $UserCLI -Password $PasswordCLI -Force:$true -NotDefault -Verbose -WarningAction SilentlyContinue
	}

$SessionID = $connection.SessionID

	If (($SessionID -eq $null) -or ($SessionID -eq "") -or (($SessionID+ + $vCenterServerName) -eq $GlobalID) )
	{
		Log-Event $WARNING_ "SessionID is empty or equal to another SessionID. SessionID = $SessionID. Exit Script"
		Exit
	}

$Global:GlobalID = $SessionID + $vCenterServerName


Log-Event $INFO_ "Connect-VIServer -Server $vCenterServerName Success. SessionID $SessionID"

$VMClusters = @()
$VMClustersArray = @{}
Try		{$VMClustersList = Get-Cluster -Server $Connection}
Catch 
{
	Log-Event $ERROR_ "Can't get clusters list view from $vCenterServerName"
}

$VMClustersDS = @()
$VMClustersDSArray = @{}
Try		{$VMDatastores = Get-View -Server $Connection -ViewType DataStore | Select Summary, MoRef, Name}
Catch 
{
	Log-Event $ERROR_ "Can't get datastores list view from $vCenterServerName"
}

$VMClustersHosts = @()
$VMClustersHostsArray = @{}
Try		{$VMhostsList = Get-View -Server $Connection -ViewType HostSystem | Select Hardware, MoRef, Name, VM}
Catch 
{
	Log-Event $ERROR_ "Can't get hosts list from $vCenterServerName"
}

$VMHostsVMs = @()
$VMHostsVMsArray = @{}
Try		{$VMList = Get-View -Server $connection -ViewType VirtualMachine | Select Summary, Config, Guest, MoRef, Name}
Catch
{
	Log-Event $ERROR_ "Can't get Virtual Machine list view from $vCenterServerName"
}



$VMBlockHBAs = @()
$VMBlockHBAsArray = @{}

$VMiSCSIHBAs = @()
$VMiSCSIHBAsArray = @{}

$VMFCHBAs = @()
$VMFCHBAsArray = @{}

Try		{$HBAs = Get-VMHostHba -Server $Connection}
Catch
{  $ErrorText = $_.Exception.Message
	Log-Event $ERROR_ "Can't get HBAs list view from $vCenterServerName. Error: $ErrorText"
}


$VMNICs = @()
$VMNICsArray = @{}


ForEach ($VMCluster in $VMClustersList)
{
	$ClusterID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id)
	$VMClusters += $ClusterID
	
	$VMClustersArray[$ClusterID] = @{}
	$VMClustersArray[$ClusterID]["ClusterName"] = $VMCluster.Name 
	$VMClustersArray[$ClusterID]["HAEnabled"] = $VMCluster.HAEnabled
	$VMClustersArray[$ClusterID]["DrsEnabled"] = $VMCluster.DrsEnabled
	$VMClustersArray[$ClusterID]["ClusterId"] = $VMCluster.Id
	$VMClustersArray[$ClusterID]["vCenterName"] = $vCenterServerName
	$VMClustersArray[$ClusterID]["DisplayName"] = $VMCluster.Name	
	
	$ViewCluster = (Get-View -Server $Connection $VMCluster.Id | Select Host, Datastore)


#=============adding datastores begin==========================
	
	$VMClusterDatastores = $ViewCluster.Datastore

	Log-Event $INFO_ "Found $($VMClusterDatastores.count) Datastores"

    ForEach ($VMClusterDatastore in $VMClusterDatastores)
    {                    
		ForEach ($VMDatastore in $VMDatastores)
		{
			if (($VMClusterDatastore.Value -eq $VMDatastore.MoRef.Value) -and ($VMDatastore.Summary.MultipleHostAccess))
            {
				
				$DSID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/DS-"+$VMDatastore.MoRef.Value)
				$VMClustersDS += $DSID
				
				$VMClustersDSArray[$DSID] = @{}
				$VMClustersDSArray[$DSID]["Name"] = $VMDatastore.Name 
				$VMClustersDSArray[$DSID]["Id"] = $VMDatastore.MoRef.Value
				$VMClustersDSArray[$DSID]["Capacity"] = $VMDatastore.Summary.Capacity/1GB
				$VMClustersDSArray[$DSID]["Type"] = $VMDatastore.Summary.Type				
				$VMClustersDSArray[$DSID]["ClusterId"] = $VMCluster.Id
				$VMClustersDSArray[$DSID]["vCenterName"] = $vCenterServerName
				$VMClustersDSArray[$DSID]["DisplayName"] = $VMDatastore.Name	
			}
        }
    }

#=============adding datastores end==========================



#=============adding hosts begin (HBAs,VMs inside)=================================

	
	$VMClusterHosts = $ViewCluster.Host

	Log-Event $INFO_ "Found $($VMClusterHosts.count) Hosts"


    ForEach ($VMClusterHost in $VMClusterHosts)
    {                    
		ForEach ($VMhost in $VMhostsList)
		{
			if ($VMClusterHost.Value -eq $VMhost.MoRef.Value) 
            {
				$HostID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value)
				$VMClustersHosts += $HostID
				
				$VMClustersHostsArray[$HostID] = @{}
				$VMClustersHostsArray[$HostID]["Name"] = $VMhost.Name
				$VMClustersHostsArray[$HostID]["Vendor"] = $VMHost.Hardware.SystemInfo.Vendor 
				$VMClustersHostsArray[$HostID]["Model"] = $VMHost.Hardware.SystemInfo.Model
				$VMClustersHostsArray[$HostID]["BiosVersion"] = $VMHost.Hardware.BiosInfo.BiosVersion
				$VMClustersHostsArray[$HostID]["BiosDate"] = $VMHost.Hardware.BiosInfo.ReleaseDate
				$VMClustersHostsArray[$HostID]["Memory"] = [math]::Round($VMHost.Hardware.MemorySize/1GB)
				$VMClustersHostsArray[$HostID]["CPUCores"] = $VMHost.Hardware.CpuInfo.NumCPUCores
				$VMClustersHostsArray[$HostID]["CPUSpeed"] = [math]::Round($VMHost.Hardware.CpuInfo.Hz/1GB,2)
				$VMClustersHostsArray[$HostID]["HostId"] = $VMhost.MoRef.Value				
				$VMClustersHostsArray[$HostID]["ClusterId"] = $VMCluster.Id
				$VMClustersHostsArray[$HostID]["vCenterName"] = $vCenterServerName
				$VMClustersHostsArray[$HostID]["DisplayName"] = $VMhost.Name

#============adding NICs begin======================================================

$vmHostforNIC = Get-VMHost -Server $connection -Name $VMhost.Name
$esxcli = Get-EsxCli -Server $connection -VMHost $vmHostforNIC #-V2
$NICsList = $esxcli.network.nic.list.Invoke() 

Log-Event $INFO_ "Found $($NICsList.count) NICs for host $($VMhost.Name)"

foreach ($NIC in $NICsList)

{

				$NICID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value + "/NIC-"+$NIC.Name)
				$VMNICs += $NICID
				
				$VMNICsArray[$NICID] = @{}
				$VMNICsArray[$NICID]["Name"] = $NIC.Name
				$VMNICsArray[$NICID]["Description"] = $NIC.Description
				$VMNICsArray[$NICID]["Driver"] = $NIC.Driver
				$VMNICsArray[$NICID]["Duplex"] = $NIC.Duplex
				$VMNICsArray[$NICID]["MACAddress"] = $NIC.MACAddress
				$VMNICsArray[$NICID]["MTU"] = $NIC.MTU
				$VMNICsArray[$NICID]["PCIDevice"] = $NIC.PCIDevice
				$VMNICsArray[$NICID]["Speed"] = $NIC.Speed
				$VMNICsArray[$NICID]["VMHost"] = $VMhost.Name

				$VMNICsArray[$NICID]["HostId"] = $VMhost.MoRef.Value							
				$VMNICsArray[$NICID]["ClusterId"] = $VMCluster.Id
				$VMNICsArray[$NICID]["vCenterName"] = $vCenterServerName
				$VMNICsArray[$NICID]["DisplayName"] = $VMhost.Name +":"+$NIC.Name 
}

#============adding NICs end======================================================

#============adding HBAs begin======================================================

foreach ($HBA in $HBAs)

{

    if ("HostSystem-"+$VMhost.MoRef.Value -eq $HBA.VMHostId)

    {

    switch($HBA.Type)
        {

        "Block" {

        $BlockHBAID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value+"/BlockHBA-"+$HBA.Name)

        $VMBlockHBAs += $BlockHBAID 
        $VMBlockHBAsArray[$BlockHBAID] = @{}
        $VMBlockHBAsArray[$BlockHBAID]["Name"] = $HBA.Name

		$VMBlockHBAsArray[$BlockHBAID]["Key"] = $HBA.Key 
		$VMBlockHBAsArray[$BlockHBAID]["Model"] = $HBA.Model 
		$VMBlockHBAsArray[$BlockHBAID]["Pci"] = $HBA.Pci 
		$VMBlockHBAsArray[$BlockHBAID]["Driver"] = $HBA.Driver 
		$VMBlockHBAsArray[$BlockHBAID]["Bus"] = $HBA.Bus 
		
		$VMBlockHBAsArray[$BlockHBAID]["VMHost"] = $HBA.VMHost.Name


		$VMBlockHBAsArray[$BlockHBAID]["VMHostId"] = $HBA.VMHostId 
		$VMBlockHBAsArray[$BlockHBAID]["Type"] = $HBA.Type 
		$VMBlockHBAsArray[$BlockHBAID]["Uid"] = $HBA.Uid 



        $VMBlockHBAsArray[$BlockHBAID]["HostId"] = $VMhost.MoRef.Value							
		$VMBlockHBAsArray[$BlockHBAID]["ClusterId"] = $VMCluster.Id
		$VMBlockHBAsArray[$BlockHBAID]["vCenterName"] = $vCenterServerName
		$VMBlockHBAsArray[$BlockHBAID]["DisplayName"] = $VMhost.Name +":"+$HBA.Name       
        "block HBA Found"
        
        }
        "IScsi" {
        $iSCSIHBAID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value+"/iSCSIHBA-"+$HBA.Name)

        $VMiSCSIHBAs  += $iSCSIHBAID 
        $VMiSCSIHBAsArray[$iSCSIHBAID] = @{}
        $VMiSCSIHBAsArray[$iSCSIHBAID]["Name"] = $HBA.Name 

		$VMiSCSIHBAsArray[$iSCSIHBAID]["Key"] = $HBA.Key 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["Model"] = $HBA.Model 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["Pci"] = $HBA.Pci 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["Driver"] = $HBA.Driver 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["Bus"] = $HBA.Bus 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["VMHostId"] = $HBA.VMHostId 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["VMHost"] = $HBA.VMHost.Name 



		$VMiSCSIHBAsArray[$iSCSIHBAID]["Type"] = $HBA.Type 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["Uid"] = $HBA.Uid 

		$VMiSCSIHBAsArray[$iSCSIHBAID]["AuthenticationCapability"] = $HBA.AuthenticationCapability 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["AuthenticationProperties"] = $HBA.AuthenticationProperties 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["CurrentSpeedMb"] = $HBA.CurrentSpeedMb 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["IScsiAlias"] = $HBA.IScsiAlias 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["IsSoftwareBased"] = $HBA.IsSoftwareBased 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["IScsiName"] = $HBA.IScsiName 
		$VMiSCSIHBAsArray[$iSCSIHBAID]["MaxSpeedMb"] = $HBA.MaxSpeedMb 


        $VMiSCSIHBAsArray[$iSCSIHBAID]["HostId"] = $VMhost.MoRef.Value							
		$VMiSCSIHBAsArray[$iSCSIHBAID]["ClusterId"] = $VMCluster.Id
		$VMiSCSIHBAsArray[$iSCSIHBAID]["vCenterName"] = $vCenterServerName
		$VMiSCSIHBAsArray[$iSCSIHBAID]["DisplayName"] = $VMhost.Name +":"+$HBA.Name     
        
        
        
        }
        "FibreChannel"{
        
         $FCHBAID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value+"/FCHBA-"+$HBA.Name)

        $VMFCHBAs  += $FCHBAID 
        $VMFCHBAsArray[$FCHBAID] = @{}
        $VMFCHBAsArray[$FCHBAID]["Name"] = $HBA.Name 

		$VMFCHBAsArray[$FCHBAID]["Key"] = $HBA.Key 
		$VMFCHBAsArray[$FCHBAID]["Model"] = $HBA.Model 
		$VMFCHBAsArray[$FCHBAID]["Pci"] = $HBA.Pci 
		$VMFCHBAsArray[$FCHBAID]["Driver"] = $HBA.Driver 
		$VMFCHBAsArray[$FCHBAID]["Bus"] = $HBA.Bus 
		$VMFCHBAsArray[$FCHBAID]["VMHostId"] = $HBA.VMHostId
		$VMFCHBAsArray[$FCHBAID]["VMHost"] = $HBA.VMHost.Name 


		$VMFCHBAsArray[$FCHBAID]["Type"] = $HBA.Type 
		$VMFCHBAsArray[$FCHBAID]["Uid"] = $HBA.Uid 

		$VMFCHBAsArray[$FCHBAID]["PortType"] = $HBA.PortType 
		$VMFCHBAsArray[$FCHBAID]["Speed"] = $HBA.Speed 
		$VMFCHBAsArray[$FCHBAID]["NodeWorldWideName"] = $HBA.NodeWorldWideName 
		$VMFCHBAsArray[$FCHBAID]["PortWorldWideName"] = $HBA.PortWorldWideName 
		
        $VMFCHBAsArray[$FCHBAID]["HostId"] = $VMhost.MoRef.Value							
		$VMFCHBAsArray[$FCHBAID]["ClusterId"] = $VMCluster.Id
		$VMFCHBAsArray[$FCHBAID]["vCenterName"] = $vCenterServerName
		$VMFCHBAsArray[$FCHBAID]["DisplayName"] = $VMhost.Name +":"+$HBA.Name        
        
        
        }
        }

     }

}


#============adding HBAs end========================================================
                
#============adding vms begin==========================================================
				
				$VMHostVMs = $VMHost.VM
			    ForEach ($VMHostVM in $VMHostVMs)
			    {                    
					ForEach ($VM in $VMList)
					{
						if ($VMHostVM.Value -eq $VM.MoRef.Value) 
			            {
							$VMID = ("vC-"+$vCenterServerName+"/CL-"+$VMCluster.Id+"/HS-"+$VMhost.MoRef.Value+"/VM-"+$VM.MoRef.Value)
							$VMHostsVMs += $VMID
						
							$VMHostsVMsArray[$VMID] = @{}
							$VMHostsVMsArray[$VMID]["Name"] = $VM.Name 
							$VMHostsVMsArray[$VMID]["GuestOS"] = $VM.Guest.GuestFullName
							$VMHostsVMsArray[$VMID]["ipAddress"] = $VM.Guest.IpAddress
							$VMHostsVMsArray[$VMID]["DNSName"] = $VM.Guest.HostName
							$VMHostsVMsArray[$VMID]["VMWareToolsVersion"] = $VM.Guest.ToolsVersion
							$VMHostsVMsArray[$VMID]["Annotations"] = $VM.Config.Annotation
							$VMHostsVMsArray[$VMID]["DatastoreURL"] = $VM.Config.Datastoreurl.Url
							$VMHostsVMsArray[$VMID]["DatastoreName"] = $VM.Config.Datastoreurl.Name
							$VMHostsVMsArray[$VMID]["NumCPU"] = $VM.Config.Hardware.NumCPU
							$VMHostsVMsArray[$VMID]["NumCoresPerSocket"] = $VM.Config.Hardware.NumCoresPerSocket
							$VMHostsVMsArray[$VMID]["MemoryMB"] = $VM.Config.Hardware.MemoryMB
							$VMHostsVMsArray[$VMID]["NumEthernetCards"] = $VM.Summary.Config.NumEthernetCards
							$VMHostsVMsArray[$VMID]["NumVirtualDisks"] = $VM.Summary.Config.NumVirtualDisks
							$VMHostsVMsArray[$VMID]["Id"] = $VM.MoRef.Value	
							$VMHostsVMsArray[$VMID]["HostId"] = $VMhost.MoRef.Value							
							$VMHostsVMsArray[$VMID]["ClusterId"] = $VMCluster.Id
							$VMHostsVMsArray[$VMID]["vCenterName"] = $vCenterServerName
							$VMHostsVMsArray[$VMID]["DisplayName"] = $VM.Name
						}
			        }
			    }

#============adding vms end==========================================================
				
			}
        }
    }	
}


#=============adding hosts end=================================
# Log-Event $INFO_ "All data collected, start to create SCOM objects"



$discoveryData = $api.CreateDiscoveryData(0, $sourceId, $managedEntityId)

Log-Event $INFO_ "Adding $($VMClusters.length) Clusters to SCOM"

$CL = 0
While ($CL -ne $VMClusters.length ) 
{
    $VMWarecluster = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.Cluster']$")
	$VMWarecluster.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterName$", $VMClustersArray[$VMClusters[$CL]]["ClusterName"])
	$VMWarecluster.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/HAEnabled$", $VMClustersArray[$VMClusters[$CL]]["HAEnabled"])
	$VMWarecluster.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/DrsEnabled$", $VMClustersArray[$VMClusters[$CL]]["DrsEnabled"])
	
	$VMWarecluster.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMClustersArray[$VMClusters[$CL]]["ClusterId"])	
	$VMWarecluster.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMClustersArray[$VMClusters[$CL]]["vCenterName"])
	$VMWarecluster.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMClustersArray[$VMClusters[$CL]]["DisplayName"])
	$discoveryData.AddInstance($VMWarecluster)	

#	Log-Event $INFO_ "Added cluster: $(VMClustersArray[$VMClusters[$CL]]["DisplayName"]) to SCOM" 
	
	$CL += 1
}	
$DS = 0

While ($DS -ne $VMClustersDS.length ) 
{
	$VMWareClusterDatastore = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.ClusterDatastore']$")
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.ClusterDatastore']/Name$", $VMClustersDSArray[$VMClustersDS[$DS]]["Name"] )
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.ClusterDatastore']/Capacity$", $VMClustersDSArray[$VMClustersDS[$DS]]["Capacity"])
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.ClusterDatastore']/Type$", $VMClustersDSArray[$VMClustersDS[$DS]]["Type"])

	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.ClusterDatastore']/Id$", $VMClustersDSArray[$VMClustersDS[$DS]]["Id"])
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMClustersDSArray[$VMClustersDS[$DS]]["ClusterId"])
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMClustersDSArray[$VMClustersDS[$DS]]["vCenterName"])
	$VMWareClusterDatastore.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMClustersDSArray[$VMClustersDS[$DS]]["DisplayName"])
	$discoveryData.AddInstance($VMWareClusterDatastore)		
		
	$DS += 1
}
	
$HS = 0
While ($HS -ne $VMClustersHosts.length ) 
{
	$VMWareHost = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.Host']$")
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostName$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["Name"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/Vendor$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["Vendor"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/Model$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["Model"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/BiosVersion$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["BiosVersion"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/BiosDate$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["BiosDate"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/Memory$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["Memory"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/CPUCores$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["CPUCores"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/CPUSpeed$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["CPUSpeed"])
		
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["HostId"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["ClusterId"])
	$VMWareHost.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["vCenterName"])
	$VMWareHost.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMClustersHostsArray[$VMClustersHosts[$HS]]["DisplayName"])
	$discoveryData.AddInstance($VMWareHost)		
		
	$HS += 1
}

$VM = 0
While ($VM -ne $VMHostsVMs.length ) 
{
	$VMWareVM = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.VirtualMachine']$")
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/Name$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["Name"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/GuestOS$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["GuestOS"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/ipAddress$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["ipAddress"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/DNSName$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["DNSName"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/VMWareToolsVersion$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["VMWareToolsVersion"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/Annotations$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["Annotations"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/DatastoreURL$",$VMHostsVMsArray[$VMHostsVMs[$VM]]["DatastoreURL"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/DatastoreName$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["DatastoreName"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/NumCPU$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["NumCPU"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/NumCoresPerSocket$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["NumCoresPerSocket"])
	
	if ([int]::tryparse($VMHostsVMsArray[$VMHostsVMs[$VM]]["MemoryMB"], [ref]$resultInt))
{
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/MemoryMB$", $resultInt)
}

	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/NumEthernetCards$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["NumEthernetCards"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/NumVirtualDisks$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["NumVirtualDisks"])

	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.VirtualMachine']/id$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["Id"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["HostId"])
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["ClusterId"] )
	$VMWareVM.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["vCenterName"])
	$VMWareVM.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMHostsVMsArray[$VMHostsVMs[$VM]]["DisplayName"] )
	$discoveryData.AddInstance($VMWareVM)
			
	$VM += 1
}		



$BlockHBAsNum = 0

if ($VMBlockHBAs.length  -gt 0) {

		While ($BlockHBAsNum -ne $VMBlockHBAs.length ) 
		{
			$BlockHBAObj = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMWareMP.Block.HBA']$")
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Name$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Name"])

			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Key$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Key"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Model$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Model"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Pci$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Pci"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Driver$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Driver"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Bus$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Bus"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHostId$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["VMHostId"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHost$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["VMHost"])
	
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Type$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Type"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Uid$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["Uid"])

			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["HostId"])
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["ClusterId"] )
			$BlockHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["vCenterName"])
			$BlockHBAObj.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMBlockHBAsArray[$VMBlockHBAs[$BlockHBAsNum]]["DisplayName"] )
			$discoveryData.AddInstance($BlockHBAObj)			
			$BlockHBAsNum++
		}
	}

$FCHBAsNum = 0

if ($VMFCHBAs.length -gt 0) 
{

	While ($FCHBAsNum -ne $VMFCHBAs.length ) 
		{
			$FCHBAObj = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMWareMP.FibreChannel.HBA']$")
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Name$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Name"])

			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Key$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Key"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Model$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Model"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Pci$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Pci"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Driver$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Driver"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Bus$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Bus"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHostId$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["VMHostId"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHost$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["VMHost"])
	
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Type$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Type"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Uid$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Uid"])

			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.FibreChannel.HBA']/PortType$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["PortType"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.FibreChannel.HBA']/Speed$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["Speed"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.FibreChannel.HBA']/NodeWorldWideName$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["NodeWorldWideName"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.FibreChannel.HBA']/PortWorldWideName$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["PortWorldWideName"])
	
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["HostId"])
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["ClusterId"] )
			$FCHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["vCenterName"])
			$FCHBAObj.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMFCHBAsArray[$VMFCHBAs[$FCHBAsNum]]["DisplayName"] )
			$discoveryData.AddInstance($FCHBAObj)			
			$FCHBAsNum++
		}
}

$iSCSIHBAsNum = 0

if ($VMiSCSIHBAs.length -gt 0) 
{

			While ($iSCSIHBAsNum -ne $VMiSCSIHBAs.length ) 
			{
				$iSCSIHBAObj = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']$")
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Name$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Name"])

				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Key$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Key"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Model$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Model"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Pci$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Pci"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Driver$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Driver"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Bus$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Bus"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHostId$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["VMHostId"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/VMHost$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["VMHost"])
		
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Type$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Type"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.HBA']/Uid$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["Uid"])
	
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/AuthenticationCapability$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["AuthenticationCapability"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/AuthenticationProperties$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["AuthenticationProperties"])
				
			if ([int]::tryparse($VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["CurrentSpeedMb$"], [ref]$resultInt))
			{
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/CurrentSpeedMb$", $resultInt)
			}	

				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/IScsiAlias$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["IScsiAlias"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/IsSoftwareBased$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["IsSoftwareBased"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/IScsiName$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["IScsiName"])
	
					if ([int]::tryparse($VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["MaxSpeedMb"], [ref]$resultInt))
			{
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMWareMP.iSCSI.HBA']/MaxSpeedMb$", $resultInt)
			}
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["HostId"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["ClusterId"] )
				$iSCSIHBAObj.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["vCenterName"])
				$iSCSIHBAObj.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMiSCSIHBAsArray[$VMiSCSIHBAs[$iSCSIHBAsNum]]["DisplayName"] )
				$discoveryData.AddInstance($iSCSIHBAObj)			
				$iSCSIHBAsNum++
			}

}

$NicNUM = 0

if ($VMNICs.length -gt 0) 
{

		While ($NicNUM -ne $VMNICs.length ) 
		{
			$NICObj = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.NIC']$")
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/Name$", $VMNICsArray[$VMNICs[$NicNUM]]["Name"])

			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/Description$", $VMNICsArray[$VMNICs[$NicNUM]]["Description"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/Driver$", $VMNICsArray[$VMNICs[$NicNUM]]["Driver"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/Duplex$", $VMNICsArray[$VMNICs[$NicNUM]]["Duplex"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/MACAddress$", $VMNICsArray[$VMNICs[$NicNUM]]["MACAddress"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/MTU$", $VMNICsArray[$VMNICs[$NicNUM]]["MTU"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/PCIDevice$", $VMNICsArray[$VMNICs[$NicNUM]]["PCIDevice"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/Speed$", $VMNICsArray[$VMNICs[$NicNUM]]["Speed"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.NIC']/VMHost$", $VMNICsArray[$VMNICs[$NicNUM]]["VMHost"])
			
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.Host']/HostId$", $VMNICsArray[$VMNICs[$NicNUM]]["HostId"])
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.Cluster']/ClusterId$", $VMNICsArray[$VMNICs[$NicNUM]]["ClusterId"] )
			$NICObj.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $VMNICsArray[$VMNICs[$NicNUM]]["vCenterName"])
			$NICObj.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $VMNICsArray[$VMNICs[$NicNUM]]["DisplayName"] )
			$discoveryData.AddInstance($NICObj)			
			$NicNUM++

		}
}



Log-Event $INFO_ "Send data to SCOM. Clusters $CL, Hosts $HS, DataStore $DS, VMs $VM, NICs $NicNUM"

$discoveryData



Try		{Disconnect-VIServer -Server $connection -Confirm:$false}
Catch 
{
	Log-Event $ERROR_ "Can't disconnect from vCenter"
	Exit
}

Log-Event $INFO_ "Script finished."


