﻿param($sourceId, $managedEntityId, $vCenters)

$api = New-Object -comObject 'MOM.ScriptAPI'
$discoveryData = $api.CreateDiscoveryData(0, $sourceId, $managedEntityId)

$vCenterServers = $vCenters.Split(";")

foreach ($vCenter IN $vCenterServers)
{

	$VMWarevCenter = $discoveryData.CreateClassInstance("$MPElement[Name='MS.VMware.Class.vCenter']$")
	$VMWarevCenter.AddProperty("$MPElement[Name='MS.VMware.Class.vCenter']/vCenterName$", $vCenter)
	$VMWarevCenter.AddProperty("$MPElement[Name='System!System.Entity']/DisplayName$", $vCenter)
	$discoveryData.AddInstance($VMWarevCenter)

}

$discoveryData