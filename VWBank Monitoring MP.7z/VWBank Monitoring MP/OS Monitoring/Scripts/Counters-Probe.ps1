﻿     Param($CounterName)
$api = new-object -comObject 'MOM.ScriptAPI';

sleep 3;

switch ($CounterName) 
    { 
	 
	 
	    "MemPrct" 
        {

		  	$TotalMemory=1
            $FreeMemory=1
            $MemoryUsedPercent=1

           $TotalMemory = (gwmi -Namespace root\cimv2 -Query 'select TotalPhysicalMemory from Win32_ComputerSystem').TotalPhysicalMemory/1024
           $FreeMemory = (gwmi -Namespace root\cimv2 -Query 'select FreePhysicalMemory from Win32_OperatingSystem').FreePhysicalMemory
           $MemoryUsedPercent = ($TotalMemory - $FreeMemory)/$TotalMemory*100

          $bag = $api.CreatePropertyBag();
          $bag.AddValue('ObjectName','Memory');
          $bag.AddValue('InstanceName','');
          $bag.AddValue('CounterName','% Used Memory');
          $bag.AddValue('Value',[double]$MemoryUsedPercent);
          $bag;        
        } 

        "CPU" 
        {

		  $ProcessorUsed =1

          $ProcessorUsed1 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed2 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed3 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed4 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed5 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed6 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed7 = (Get-WmiObject win32_processor -computername .  | Measure-Object -property LoadPercentage -Average | Select Average).Average
          $ProcessorUsed = [math]::round(($ProcessorUsed1+$ProcessorUsed2+$ProcessorUsed3+$ProcessorUsed4+$ProcessorUsed5+$ProcessorUsed6+$ProcessorUsed7)/7,2 ) 
		  
          $bag = $api.CreatePropertyBag();
          $bag.AddValue('ObjectName','CPU');
          $bag.AddValue('InstanceName','_Total');
          $bag.AddValue('CounterName','% Processor Time');
          $bag.AddValue('Value',[double]$ProcessorUsed);
          $bag;        
        } 

}