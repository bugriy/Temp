﻿function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$oAPI.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
	}
}


$oAPI=New-Object -ComObject 'MOM.ScriptApi'

$SCRIPT_NAME = 'SEP.Process.check.ps1';
$SCRIPT_EVENT_ID = 4872;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;
$WriteToEventLog = 1



$ProcessorTimeValue = [math]::Round(((( (Get-Counter '\Process(ccsvchst*)\% Processor Time').CounterSamples.cookedValue  )  ) | Measure -Sum).sum / $env:Number_of_processors,2)

$WorkingSetValue = [math]::Round((((( (Get-Counter '\Process(ccsvchst*)\Working Set').CounterSamples.cookedValue  )  ) | Measure -Sum).sum ) / 1MB ,2)

$IOReadOperations = [math]::Round((((( (Get-Counter '\Process(ccsvchst*)\IO Read Operations/sec').CounterSamples.cookedValue  )  ) | Measure -Sum).sum )  ,2)

$IOWriteOperations = [math]::Round((((( (Get-Counter '\Process(ccsvchst*)\IO Write Operations/sec').CounterSamples.cookedValue  )  ) | Measure -Sum).sum )  ,2)


 $bag = $oAPI.CreatePropertyBag();
 $bag.AddValue('CounterName','Symantec process Processor Time (Percent)');
 $bag.AddValue('Value', $ProcessorTimeValue);
 $bag.AddValue('ObjectName', "Symantec process - ccsvchst");
 $bag.AddValue('InstanceName', "_Total");
 $bag;

 $bag = $oAPI.CreatePropertyBag();
 $bag.AddValue('CounterName','Symantec process Memory Working Set (Megabytes)');
 $bag.AddValue('Value', $WorkingSetValue);
 $bag.AddValue('ObjectName', "Symantec process - ccsvchst");
 $bag.AddValue('InstanceName', "_Total");
 $bag;

  $bag = $oAPI.CreatePropertyBag();
 $bag.AddValue('CounterName','Symantec process IO Read Operations per sec');
 $bag.AddValue('Value', $IOReadOperations);
 $bag.AddValue('ObjectName', "Symantec process - ccsvchst");
 $bag.AddValue('InstanceName', "_Total");
 $bag;

  $bag = $oAPI.CreatePropertyBag();
 $bag.AddValue('CounterName','Symantec process IO Write Operations per sec');
 $bag.AddValue('Value', $IOWriteOperations);
 $bag.AddValue('ObjectName', "Symantec process - ccsvchst");
 $bag.AddValue('InstanceName', "_Total");
 $bag;

