﻿
function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$oAPI.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
	}
}


$oAPI=New-Object -ComObject 'MOM.ScriptApi'

$SCRIPT_NAME = 'SEP.check.ps1';
$SCRIPT_EVENT_ID = 4871;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;
$WriteToEventLog = 1


$SEPDefinitionsDateText = (Get-ItemProperty -Path "hklm:\SOFTWARE\Symantec\Symantec Endpoint Protection\CurrentVersion\public-opstate").LatestVirusDefsDate

$SEPDefinitionsDate = [datetime]::ParseExact($SEPDefinitionsDateText ,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)

		$Now = [datetime](Get-Date)

		$SEPDefinitionsAge =   [math]::Round(((NEW-TIMESPAN –Start $SEPDefinitionsDate –End $Now).TotalDays),1)


			if ($SEPDefinitionsAge -ge 0) 
			
			  {
			  $bag = $oAPI.CreatePropertyBag();
              $bag.AddValue('CounterName','SEPDefinitionsAge');
              $bag.AddValue('Value', $SEPDefinitionsAge);
			  $bag.AddValue('Date', $SEPDefinitionsDateText);
		      $bag;

			  $bag = $oAPI.CreatePropertyBag();
              $bag.AddValue('CounterName','SEPDefinitionsAgeReadSuccess');
              $bag.AddValue('Value', "Success");
			  $bag.AddValue('DefinitionsDate', $SEPDefinitionsDateText);
		      $bag;
			  }
			  else
			  {
			  $bag = $oAPI.CreatePropertyBag();
              $bag.AddValue('CounterName','SEPDefinitionsAgeReadSuccess');
              $bag.AddValue('Value', "Failed");
		      $bag;
			  }
