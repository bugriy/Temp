﻿param (
    [string]$SQLInstanceName
 )
 
function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$oAPI.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
        write-host $Message -ForegroundColor Yellow
	}
}

function Read-FileContent ($path)
       {       
        $OpenLogFile = [System.IO.File]::Open($path, [System.IO.FileMode]"Open", [System.IO.FileAccess]"Read", [System.IO.FileShare]"ReadWrite")
        $StreamReader = new-object System.IO.StreamReader($openLogFile,[System.Text.Encoding]::Default)
        $DSMSchedLogFileContent = $StreamReader.ReadToEnd()
        $OpenLogFile.Close()
        $DSMSchedLogFileContent.Split("`n")
        }


function Send-Bag ($ObjectName = 'ObjectName', $InstanceName = 'InstanceName', $CounterName, $Value, $Details="")

{
  $bag = $oAPI.CreatePropertyBag();
  $bag.AddValue('ObjectName',$ObjectName);
  $bag.AddValue('InstanceName',$InstanceName);
  $bag.AddValue('CounterName',$CounterName);
  $bag.AddValue('Value', $Value);
  if ($Details -ne "") {$bag.AddValue('Details', $Details);}
  $bag;

  Log-Event -Level $INFO_ "BAG. ObjectName: $ObjectName InstanceName: $InstanceName CounterName: $CounterName Value: $Value"

  write-host "ObjectName: "$ObjectName -ForegroundColor Cyan
  write-host "InstanceName: "$InstanceName -ForegroundColor Cyan
  write-host "CounterName: "$CounterName -ForegroundColor Cyan
  write-host "Value: "$Value -ForegroundColor Cyan
  write-host "Details: "$Details -ForegroundColor Cyan

}


function Log-Final
{
$ScriptEndTime = Get-Date
$ScriptRunTime = ($ScriptEndTime - $ScriptStartTime).TotalSeconds
Log-Event $INFO_ "Script finished. Runtime: $ScriptRunTime sec. $SQLInstanceName" 
exit
}


function check-backup
{

    param ($LogFilesPath, $LogFileName, $BackupType, $SQLInstanceName,
      [ValidateSet("Days", "Hours", "Minutes")][string]$Age,
      [ValidateSet("Hours", "Minutes", "Seconds")][string]$Duration)



if (!( Test-Path ("$LogFilesPath\$($LogFileName)") ) )

{          
   Log-Event $ERROR_ "$BackupType Backup Log file not found. Path: $LogFilesPath, FileName: $LogFileName"
   Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup log file found" -Value "Bad" -Details "$BackupType Backup Log file not found. Path: $LogFilesPath, FileName: $LogFileName"
   exit

}


   Log-Event $INFO_ "$BackupType Backup Log file found. Path: $LogFilesPath, FileName: $LogFileName"

   Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup log file found" -Value "Good" -Details "$BackupType Backup Log file found. Path: $LogFilesPath, FileName: $LogFileName"
   
  $DSMSchedLogFileContent = Read-FileContent -path "$LogFilesPath\$LogFileName"
  
  $BackupStartLines = $DSMSchedLogFileContent | select-string -pattern "Connecting to TSM Server as node '$SQLInstanceName'..."


  if (!($BackupStartLines.count -gt 0))
   {   
   Log-Event $ERROR_ "Pattern Connecting to TSM Server as node: $SQLInstanceName not found in log file. Instance not backed up. Exit. Path: $LogFilesPath, FileName: $LogFileName"
   Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup. Instance backed up" -Value "Bad" -Details "Pattern Connecting to TSM Server as node $SQLInstanceName not found in log file. Instance not backed up. Exit. Path: $LogFilesPath, FileName: $LogFileName"
   exit   
   }

   Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup. Instance backed up" -Value "Good" -Details "Pattern Connecting to TSM Server as node $SQLInstanceName found in log file. Instance backed up. Path: $LogFilesPath, FileName: $LogFileName"
 

   $LineNumber = ($BackupStartLines | Select-Object -Last 1).LineNumber

   $DSMSchedLogFileContent[$LineNumber]

   $BackupStartTimeLine = $DSMSchedLogFileContent[$LineNumber-15]

   $BackupStartTimeText = ($BackupStartTimeLine -split " START")[0]

   $BackupStartTimeText = ($BackupStartTimeText -split " ")[1] + " " + ($BackupStartTimeText -split " ")[2]

   $BackupStartTimeDate = [datetime]::ParseExact($BackupStartTimeText ,'MM/dd/yyyy HH:mm:ss.ff',[Globalization.CultureInfo]::InvariantCulture)

   write-host "Backup start: $BackupStartTimeDate" -ForegroundColor Green


	 $Now = Get-Date

    $SQLBackupAge = (NEW-TIMESPAN –Start $BackupStartTimeDate –End $Now).("Total$Age")

   	
   $SQLBackupAge = [math]::Round($SQLBackupAge,2)

	Log-Event $INFO_ "$SQLInstanceName $BackupType Backup Age ($Age): $SQLBackupAge"
		
	 if ($SQLBackupAge -gt 0)
	 {
        Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup age ($Age)" -Value ([double]$SQLBackupAge)
	 }

 
   for ($i=$LineNumber; $i -lt $DSMSchedLogFileContent.Count;$i++)

   {
     
       if ( $DSMSchedLogFileContent[$i] -like "*FINISH*")
		 {
     
		 $BackupFinishTimeText = ($DSMSchedLogFileContent[$i]  -split " FINISH")[0]

		 $BackupFinishTimeText = ($BackupFinishTimeText -split " ")[1] + " " + ($BackupFinishTimeText -split " ")[2]

		 $BackupFinishTimeDate = [datetime]::ParseExact($BackupFinishTimeText ,'MM/dd/yyyy HH:mm:ss.ff',[Globalization.CultureInfo]::InvariantCulture)

		 write-host "Backup finish: $BackupFinishTimeDate" -ForegroundColor Green

   $SQLBackupDuration = (NEW-TIMESPAN –Start $BackupStartTimeDate –End $BackupFinishTimeDate).("Total$Duration")


             $SQLBackupDuration = [math]::Round($SQLBackupDuration,2)
  
	 
		 Log-Event $INFO_ "$SQLInstanceName $BackupType Backup Duration ($Duration): $SQLBackupDuration"

         Send-Bag -ObjectName "TSM SQL Instance $BackupType Backup" -InstanceName $SQLInstanceName -CounterName "$BackupType backup duration ($Duration)" -Value ([double]$SQLBackupDuration)
			 
			break							  
							  
			}  

}
}


$ScriptStartTime = Get-Date

$oAPI=New-Object -ComObject 'MOM.ScriptApi'

$SCRIPT_NAME = 'TSM.SQL.Instance.Backup.Check.ps1';
$SCRIPT_EVENT_ID = 8823;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;
$WriteToEventLog = 1

Log-Event $INFO_ "Script started. SQLInstanceName=$SQLInstanceName" 


 if ($PSBoundParameters.Count -lt 1) {
 
 Log-Event $INFO_ "Number of parameters less than 1."
 Log-Final
 
 
 }
 
try {
	$SchedulerLogFilePath = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters" -Name "ScheduleLog").ScheduleLog

	$LogFilesPath = Split-Path $SchedulerLogFilePath -Parent

	Log-Event $INFO_ "Log file path found in registry: $LogFilesPath"
    Send-Bag -ObjectName 'TSM SQL Instance Backup' -InstanceName $SQLInstanceName -CounterName 'Log files path found in registry' -Value "Good" -Details "Log files path found in registry. Registry path - hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters\ScheduleLog. Log files path: $LogFilesPath"
    
}
catch
{
	Log-Event $ERROR_ "Log files path not found in registry. Path: Path - hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters\ScheduleLog"

    Send-Bag -ObjectName 'TSM SQL Instance Backup' -InstanceName $SQLInstanceName -CounterName 'Log files path found in registry' -Value "Bad" -Details "Log files path not found in registry. Registry path - hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters\ScheduleLog. Log files path: $LogFilesPath"
        		
	Log-Final
}

#$LogFilesPath = "C:\ROSS\2017-09-28 - VW\SQL Logs"


$DiffLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-diff.sched*.log" -File | sort LastWriteTime -Descending | Select -First 1).Name

$FullLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-full.sched*.log" -File | sort LastWriteTime -Descending | Select -First 1).Name

$IncLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-log.sched*.log" -File | sort LastWriteTime -Descending | Select -First 1).Name


check-backup -LogFilesPath $LogFilesPath -LogFileName $FullLogFileName -BackupType "Full" -SQLInstanceName $SQLInstanceName -Age "days" -Duration "hours"
check-backup -LogFilesPath $LogFilesPath -LogFileName $DiffLogFileName -BackupType "Diff" -SQLInstanceName $SQLInstanceName -Age "Hours" -Duration "Minutes"
check-backup -LogFilesPath $LogFilesPath -LogFileName $IncLogFileName -BackupType "Inc" -SQLInstanceName $SQLInstanceName -Age "minutes" -Duration "Seconds"


Log-Final