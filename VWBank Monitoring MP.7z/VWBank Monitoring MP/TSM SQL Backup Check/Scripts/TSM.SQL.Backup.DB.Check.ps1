﻿param (
    [string]$SQLInstanceName,
	[string]$SQLDBName,
	[string]$RecoveryModel
 )
 
 function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$oAPI.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
        write-host $Message -ForegroundColor Yellow
	}
}

function Read-FileContent ($path)
       {       
        $OpenLogFile = [System.IO.File]::Open($path, [System.IO.FileMode]"Open", [System.IO.FileAccess]"Read", [System.IO.FileShare]"ReadWrite")
        $StreamReader = new-object System.IO.StreamReader($openLogFile,[System.Text.Encoding]::Default)
        $DSMSchedLogFileContent = $StreamReader.ReadToEnd()
        $OpenLogFile.Close()
        $DSMSchedLogFileContent.Split("`n")
        }


function Send-Bag ($ObjectName = 'ObjectName', $InstanceName = 'InstanceName', $CounterName, $Value, $Details="")

{
  $bag = $oAPI.CreatePropertyBag();
  $bag.AddValue('ObjectName',$ObjectName);
  $bag.AddValue('InstanceName',$InstanceName);
  $bag.AddValue('CounterName',$CounterName);
  $bag.AddValue('Value', $Value);
  if ($Details -ne "") {$bag.AddValue('Details', $Details);}
  $bag;

  write-host $ObjectName -ForegroundColor Cyan
  write-host $InstanceName -ForegroundColor Cyan
  write-host $CounterName -ForegroundColor Cyan
  write-host $Value -ForegroundColor Cyan
  write-host $Details -ForegroundColor Cyan

}


function Log-Final
{
$ScriptEndTime = Get-Date
$ScriptRunTime = ($ScriptEndTime - $ScriptStartTime).TotalSeconds
Log-Event $INFO_ "Script finished. Runtime: $ScriptRunTime sec." 
exit
}


function check-backup ($LogFilesPath, $LogFileName, $BackupType)
{


if (!(Test-Path ("$LogFilesPath\$($LogFileName)")) )
{

  Log-Event $ERROR_ "$BackupType Backup Log file not found. Path: $LogFilesPath, FileName: $LogFileName"
  exit
}


   Log-Event $INFO_ "$BackupType Backup Log file found. Path: $LogFilesPath, FileName: $LogFileName. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName"

   $DSMSchedLogFileContent = Read-FileContent -path "$LogFilesPath\$($LogFileName)"
     
   $BackupStartLines = $DSMSchedLogFileContent | select-string -pattern "Connecting to TSM Server as node '$SQLInstanceName'..."

   if (!($BackupStartLines.count -gt 0))
   {
   
   Log-Event $ERROR_ "Pattern Connecting to TSM Server as node $SQLInstanceName not found in log file. Instance not backed up. Exit. Path: $LogFilesPath, FileName: $LogFileName"
   exit   
   }

   $LineNumber = ($BackupStartLines | Select-Object -Last 1).LineNumber
   
   write-host "First line of last backup record: "  $DSMSchedLogFileContent[$LineNumber] -ForegroundColor Green
  
 
   $BackupFinished = $false
   $DatabaseBackedUpSeccessfuly = $false

   for ($i=$LineNumber; $i -lt $DSMSchedLogFileContent.Count;$i++)

   {    

            if ( $DSMSchedLogFileContent[$i] -like "*Backup of $SQLDBName completed successfully.*")
             {
             
             $DatabaseBackedUpSeccessfuly = $true 
             
             write-host "DB backup success line was found: "  $DSMSchedLogFileContent[$i] -ForegroundColor Green
                           
             }


             if ( $DSMSchedLogFileContent[$i] -like "*FINISH*")
             {             
             $BAckupFinished = $true

             write-host "instance backup finish line was found: "  $DSMSchedLogFileContent[$i]  -ForegroundColor Green

             break            
             }

      
   }


   if ($DatabaseBackedUpSeccessfuly) #если база данных забэкаплена успешно
   {   
   Log-Event $INFO_ "Database $SQLDBName $BackupType backup was successful. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName"
   Send-Bag -ObjectName "DB Backup" -InstanceName $SQLDBName -CounterName "DB $BackupType back up result" -Value "Successful" -Details "Last DB $SQLDBName $BackupType back up was succesful. String 'Backup of $SQLDBName completed successfully' found in log: $LogFilesPath\$LogFileName."
   }

   if ( ($BackupFinished -eq $true  ) -and ($DatabaseBackedUpSeccessfuly -eq $false)  ) #если бэкап уже прошёл, а сообщения об успешном бэкапе базы ещё нет
   {   
    Log-Event $ERROR_ "Database $SQLDBName $BackupType backup was not successful. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName"
    Send-Bag -ObjectName "DB Backup" -InstanceName $SQLDBName -CounterName "DB $BackupType back up result" -Value 'Failed' -Details "Last DB $SQLDBName $BackupType back up was not succesful. String 'Backup of $SQLDBName completed successfully' not found in log: $LogFilesPath\$LogFileName."
   }   


   if ( ($BackupFinished -eq $false  ) -and  ($DatabaseBackedUpSeccessfuly -eq $false) ) # если бэкап ещё не завершился, и сообщения об успешном бэкапе базы ещё нет
   {
   Log-Event $INFO_ "$BackupType backup in process, skip check this time. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName"
   }   
    
 
}


$ScriptStartTime = Get-Date

$oAPI=New-Object -ComObject 'MOM.ScriptApi'

$SCRIPT_NAME = 'TSM.SQL.DB.Backup.Check.ps1';
$SCRIPT_EVENT_ID = 8824;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;
$WriteToEventLog = 1

Log-Event $INFO_ "Script started. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName, RecoveryModel=$RecoveryModel" 


 if ($PSBoundParameters.Count -lt 2)
 {
 
 Log-Event $INFO_ "Number of parameters less than 2."
 Log-Final

 }
 
try {

	$SchedulerLogFilePath = (Get-ItemProperty -Path "hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters" -Name "ScheduleLog").ScheduleLog

	$LogFilesPath = Split-Path $SchedulerLogFilePath -Parent

	Log-Event $INFO_ "Log file path found in registry: $LogFilesPath. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName" 	

}

catch

{

	Log-Event $ERROR_ "Log files path not found in registry. Path: Path - hklm:\SYSTEM\CurrentControlSet\Services\TSM Scheduler for SQL - $SQLInstanceName\Parameters\ScheduleLog. SQLInstanceName=$SQLInstanceName, DBName=$SQLDBName"

	Log-Final
	
}

#$LogFilesPath = "C:\ROSS\2017-09-28 - VW\SQL Logs"


$DiffLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-diff.sched*.log" -File | sort LastWriteTime -Descending | Select -First 1).Name
check-backup -LogFilesPath $LogFilesPath -LogFileName $DiffLogFileName -BackupType "diff"


$FullLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-full.sched*.log" -File | sort LastWriteTime -Descending | Select -First 1).Name
check-backup -LogFilesPath $LogFilesPath -LogFileName $FullLogFileName -BackupType "full"

if ($RecoveryModel -eq "FULL")
{
	$IncLogFileName =  (Get-ChildItem -Path $LogFilesPath -Filter "tdpsqlc-log.sched*.log" -File   | sort LastWriteTime -Descending | Select -First 1).Name
	check-backup -LogFilesPath $LogFilesPath -LogFileName $IncLogFileName -BackupType "inc"
}

Log-Final