﻿function Log-Event ($Level, $Message)
{
	$Message = "`n" + $Message
	if (($WriteToEventLog -ne 0) -or ($Level -ne $INFO_ ))
	{
		$oAPI.LogScriptEvent($SCRIPT_NAME,$SCRIPT_EVENT_ID,$Level,$Message)
        # write-host $Message -ForegroundColor Yellow
	}
}


function Send-Bag ($ObjectName = 'ObjectName', $InstanceName = 'InstanceName', $CounterName, $Value, $Details="")

{
  $bag = $oAPI.CreatePropertyBag();
  $bag.AddValue('ObjectName',$ObjectName);
  $bag.AddValue('InstanceName',$InstanceName);
  $bag.AddValue('CounterName',$CounterName);
  $bag.AddValue('Value', $Value);
  if ($Details -ne "") {$bag.AddValue('Details', $Details);}
  $bag;

 # write-host $ObjectName -ForegroundColor Cyan
 # write-host $InstanceName -ForegroundColor Cyan
 # write-host $CounterName -ForegroundColor Cyan
 # write-host $Value -ForegroundColor Cyan
 # write-host $Details -ForegroundColor Cyan

}


function Read-FileContent ($path)

       {       
        $OpenLogFile = [System.IO.File]::Open($path, [System.IO.FileMode]"Open", [System.IO.FileAccess]"Read", [System.IO.FileShare]"ReadWrite")
        $StreamReader = new-object System.IO.StreamReader($openLogFile,[System.Text.Encoding]::Default)
        $DSMSchedLogFileContent = $StreamReader.ReadToEnd()
        $OpenLogFile.Close()
        $DSMSchedLogFileContent.Split("`n")
        }


function Log-Final
{
$ScriptEndTime = Get-Date
$ScriptRunTime = ($ScriptEndTime - $ScriptStartTime).TotalSeconds
Log-Event $INFO_ "Script finished. Runtime: $ScriptRunTime sec." 
exit
}

$ScriptStartTime = Get-Date

$oAPI=New-Object -ComObject 'MOM.ScriptApi'

$SCRIPT_NAME = 'TSM.BackupClient.SchedulerLogParser.ps1';
$SCRIPT_EVENT_ID = 8822;
$ERROR_ = 1;
$WARNING_ = 2;
$INFO_ = 4;
$WriteToEventLog = 0

Log-Event $INFO_ "Script started" 


#$DSMSchedLogFilePath = "C:\ROSS\2018-08-20 VW bank TSM backup\rus-log-systemstate"
$DSMSchedLogFilePath = $env:ProgramFiles + "\Tivoli\TSM\baclient"

$DSMSchedLogFileName = "dsmsched.log"


# Проверяем, установлен ли клиент бэкапа - по ветке реестра

if ( !(Test-Path "HKLM:\\SOFTWARE\IBM\ADSM\CurrentVersion\Api64"))
{

  Send-Bag -CounterName 'TSM Backup Client Installed' -Value "Bad" -Details "TSM Backup Client not installed. Registry key: SOFTWARE\IBM\ADSM\CurrentVersion\Api64 not found"
    
  Log-Event $ERROR_ "TSM Backup Client not installed. Registry key: SOFTWARE\IBM\ADSM\CurrentVersion\Api64 not found"

 Send-Bag -CounterName 'TSM Backup Client Service Found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'Log file found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'Log file locale consistent' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'System State String Found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."


  Log-Final

}


  Send-Bag -CounterName 'TSM Backup Client Installed' -Value "Good" -Details "TSM Backup Client installed. Registry key: SOFTWARE\IBM\ADSM\CurrentVersion\Api64 found"
    
  Log-Event $INFO_ "TSM Backup Client installed. Registry key: SOFTWARE\IBM\ADSM\CurrentVersion\Api64 found"


# Проверяем, установлен ли клиент бэкапа - по сервису

if (   (get-service | where {$_.name -like "TSM * Acceptor"}).count -eq 0)

{

  Send-Bag -CounterName 'TSM Backup Client Service Found' -Value "Bad" -Details "TSM Backup Client Service Not Found. Number of TSM * Acceptor services = 0"
    
  Log-Event $ERROR_ "TSM Backup Client Service Not Found. Number of TSM * Acceptor services = 0"

 Send-Bag -CounterName 'Log file found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'Log file locale consistent' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'System State String Found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."

  Log-Final


}

  Send-Bag -CounterName 'TSM Backup Client Service Found' -Value "Good" -Details "TSM Backup Client Service Found. Number of TSM * Acceptor services > 0"
    
  Log-Event $INFO_ "TSM Backup Client Service Found. Number of TSM * Acceptor services > 0"



# Проверяем, существует ли лог файл

 if ( !(Test-Path "$DSMSchedLogFilePath\$DSMSchedLogFileName") ) 

 {
 "File not found"

  Send-Bag -CounterName 'Log file found' -Value "Bad" -Details "File $DSMSchedLogFileName not found in folder $DSMSchedLogFilePath"
    
  Log-Event $ERROR_ "File $DSMSchedLogFilePath\$DSMSchedLogFileName not found"

 Send-Bag -CounterName 'Log file locale consistent' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName 'System State String Found' -Value "Good" -Details "Reset due to previous monitors are already red."
 Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details "Reset due to previous monitors are already red."
 Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."

  Log-Final
 }


        Send-Bag -CounterName 'Log file found' -Value "Good" -Details "File $DSMSchedLogFileName was found in folder $DSMSchedLogFilePath"
 
  	    Log-Event $INFO_ "File $DSMSchedLogFilePath\$DSMSchedLogFileName found" 
    

# Читаем лог файл в переменную

$DSMSchedLogFileContent  = Read-FileContent -path "$DSMSchedLogFilePath\$DSMSchedLogFileName"


# Проверяем, что локаль лог файла совпадает с локалью системы

#$SystemLocaleName = (Get-WinSystemLocale).Name


if ($DSMSchedLogFileContent | select-string -pattern "Планировщик"  | select -last 1)
{
$LogFileLocale = "Russian"
}
elseif ($DSMSchedLogFileContent | select-string -pattern "Scheduler"  | select -last 1)
{
$LogFileLocale = "English"
}
else
{
$LogFileLocale = "Unknown"
}


if ( ($LogFileLocale -eq "Unknown")  )
{
     Send-Bag -CounterName 'Log file locale consistent' -Value "Bad" -Details "Locale of log file unknown."
			
     Log-Event $ERROR_ "Locale of log file unknown."

     Send-Bag -CounterName 'System State String Found' -Value "Good" -Details "Reset due to previous monitors are already red."
     Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details "Reset due to previous monitors are already red."
	 Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."
     Log-Final

}

     Send-Bag -CounterName 'Log file locale consistent' -Value "Good" -Details "Locale of log $DSMSchedLogFilePath\$DSMSchedLogFileName - $LogFileLocale"
			
     Log-Event $INFO_ "Locale of log $DSMSchedLogFilePath\$DSMSchedLogFileName - $LogFileLocale"



# инициализируем словарь в зависимости от локали 

if ($LogFileLocale -eq "Russian")

{
    $Dictionary = @{IncrementalBackupOfVolumeSystemstate = "Инкрементное резервное копирование тома 'SYSTEMSTATE'";  FullDateTimeFormat = 'dd.MM.yyyy HH:mm:ss'; Succesful = "Успешное"; ElapsedProcessingTime = "Время с начала обработки:";}
}
else
{
    $Dictionary = @{IncrementalBackupOfVolumeSystemstate = "Incremental backup of volume 'SYSTEMSTATE'";  FullDateTimeFormat = "MM/dd/yyyy HH:mm:ss"; Succesful = "Successful"; ElapsedProcessingTime = "Elapsed processing time:";}
}



# Ищем в логе строку SystemState
          
 $systemStateBackupEndLine = $DSMSchedLogFileContent | select-string -pattern "SystemState\\NULL\\System State\\SystemState"  | select -last 1

# Если строчки нет, то значит SystemState ни разу не бэкапился

if (!($systemStateBackupEndLine))
{

     Send-Bag -CounterName 'System State String Found' -Value "Bad" -Details "The string SystemState was not found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName"
			
     Log-Event $ERROR_ "The string SystemState was not found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName" 

     Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details "Reset due to previous monitors are already red."
     Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."

     Log-Final

}

            Send-Bag -CounterName 'System State String Found' -Value "Good" -Details "The string SystemState was found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName"
 
			Log-Event $INFO_ "The string SystemState was found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName" 


# считаем продолжительность последнего бэкапа SystemState

            $SystemStateBackupEndTimeString = $systemStateBackupEndLine.toString().Split(" ")[0] + " " + $systemStateBackupEndLine.toString().Split(" ")[1]
                        
            $SystemStateBackupEndTime = [datetime]::ParseExact($SystemStateBackupEndTimeString , $Dictionary.FullDateTimeFormat,[Globalization.CultureInfo]::InvariantCulture)

            $systemStateBackupStartLine = $DSMSchedLogFileContent | select-string -pattern $Dictionary.IncrementalBackupOfVolumeSystemstate  | select -last 1

            $SystemStateBackupStartTimeString = $systemStateBackupStartLine.toString().Split(" ")[0] + " " + $systemStateBackupStartLine.toString().Split(" ")[1]

            $SystemStateBackupStartTime = [datetime]::ParseExact($SystemStateBackupStartTimeString ,$Dictionary.FullDateTimeFormat,[Globalization.CultureInfo]::InvariantCulture)
			
            $SystemStateBackupDurationMinutes = (NEW-TIMESPAN –Start $SystemStateBackupStartTime –End $SystemStateBackupEndTime).TotalMinutes
            
			if ($SystemStateBackupDurationMinutes -le 0) {
			$SystemStateBackupDurationMinutes = 0
			Log-Event $INFO_ "Backup is still in process. System State Backup Duration (minutes) = 0" 
			}			


            Send-Bag -ObjectName 'IBM TSM Backup' -InstanceName 'SystemState' -CounterName 'Operation System State Backup Duration (Minutes)' -Value $SystemStateBackupDurationMinutes

     		Log-Event $INFO_ "Counter: System State Backup Duration (minutes), Value: $SystemStateBackupDurationMinutes" 


#считаем возраст последнего бэкапа SystemState

            $currentDate = get-date           

            $SystemStateBackupAge = [math]::Round( (NEW-TIMESPAN –Start $SystemStateBackupStartTime –End $currentDate).TotalHours, 2)
           
            Send-Bag -ObjectName 'IBM TSM Backup' -InstanceName 'SystemState' -CounterName 'Operation System State Backup Age (Hours)' -Value $SystemStateBackupAge
                   
			Log-Event $INFO_ "Counter: System State Backup Age (hours), Value: $SystemStateBackupAge" 


# смотрим, завершился ли последний бэкап SystemState удачей

            $systemStateBackupEndLineText = [string]$systemStateBackupEndLine

             if  (!($systemStateBackupEndLine | select-string -pattern $Dictionary.Succesful))

             {

             Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Failed' -Details $systemStateBackupEndLineText
             
			 Log-Event $INFO_ "Last System State Backup Result = Failed. Details = $systemStateBackupEndLineText"

             Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "Reset due to previous monitors are already red."

             Log-Final
             
             }


 Send-Bag -ObjectName 'TSM Backup' -InstanceName 'SystemState' -CounterName 'Last System State Backup Result' -Value 'Successful' -Details $systemStateBackupEndLineText
             
 Log-Event $INFO_ "Last System State Backup Result = Successful. Details = $systemStateBackupEndLineText"




      $BackupDurationLine = $DSMSchedLogFileContent | select-string -pattern $Dictionary.ElapsedProcessingTime | select -last 1


	  if ($BackupDurationLine)
	  {

            Send-Bag -CounterName "Backup elapsed time found" -Value "Good" -Details "The string 'Elapsed processing time' was found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName"

            $BackupDurationTime = (($BackupDurationLine.toString() -split $Dictionary.ElapsedProcessingTime)[1]).Trim()
            
			$BackupDurationTime = [datetime]::ParseExact($BackupDurationTime,"HH:mm:ss",[Globalization.CultureInfo]::InvariantCulture)

			$BackupDurationMinutes = (New-TimeSpan -Start (Get-Date).Date -End $BackupDurationTime).TotalMinutes

			$BackupDurationMinutes = [math]::Round($BackupDurationMinutes,0)

            Send-Bag -ObjectName "IBM TSM Backup" -InstanceName "Total time" -CounterName "Total Backup Elapsed Time (Minutes)" -Value "$BackupDurationMinutes"

		    Log-Event $INFO_ "Counter: Backup elapsed time (minutes), Value: $BackupDurationMinutes" 
	  
	  
	  }
	  else
		 {

            Send-Bag -CounterName 'Backup elapsed time found' -Value "Bad" -Details "The string 'Elapsed processing time' was not found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName"
      
    		Log-Event $ERROR_ "The string Elapsed processing time was not found in log file: $DSMSchedLogFilePath\$DSMSchedLogFileName" 

            Log-Final
		}




 Log-Final