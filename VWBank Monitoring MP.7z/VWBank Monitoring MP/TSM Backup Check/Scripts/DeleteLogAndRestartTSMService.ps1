﻿#$DSMSchedLogFilePath = "C:\ROSS\2018-08-20 VW bank TSM backup\rus-log-systemstate"

function Read-FileContent ($path)

       {       
        $OpenLogFile = [System.IO.File]::Open($path, [System.IO.FileMode]"Open", [System.IO.FileAccess]"Read", [System.IO.FileShare]"ReadWrite")
        $StreamReader = new-object System.IO.StreamReader($openLogFile,[System.Text.Encoding]::Default)
        $DSMSchedLogFileContent = $StreamReader.ReadToEnd()
        $OpenLogFile.Close()
        $DSMSchedLogFileContent.Split("`n")
        }



$DSMSchedLogFilePath = $env:ProgramFiles + "\Tivoli\TSM\baclient"

$DSMSchedLogFileName = "dsmsched.log"


if ( !(Test-Path "$DSMSchedLogFilePath\$DSMSchedLogFileName") ) 

 {
 write-host "File not found: $DSMSchedLogFilePath\$DSMSchedLogFileName"
	 exit
  }

  Write-Host "File $DSMSchedLogFilePath\$DSMSchedLogFileName found."


  try
  {
  write-host "Removing file $DSMSchedLogFilePath\$DSMSchedLogFileName"
	  
   Remove-Item -Path $DSMSchedLogFilePath\$DSMSchedLogFileName -Force -Verbose -ErrorAction Stop

   write-host "Success."
  
  }
  catch
  {
  $ErrorText = $_.Exception.Message
  write-host "Failed. $ErrorText"
   exit
  }

  Write-Host "Looking for TSM Service"

  $TSMService = get-service | where {$_.name -like "TSM * Acceptor"} | select -First 1

  if ($TSMService)
  {
   Write-Host "TSM Service found: $($TSMService.Name)"
    }
  else
  {
  Write-Host "TSM Service not found"
  exit
  }

  try
  {

	Write-Host "Restarting service $($TSMService.Name)"

    $TSMService | Restart-Service -Verbose -ErrorAction Stop

	  Write-Host "Service $($TSMService.Name) restarted"
  
  }
  catch
  {
	  $ErrorText = $_.Exception.Message
		Write-Host "Error. $ErrorText" 
	  exit
  }



  $TSMService = get-service | where {$_.name -like "TSM * Scheduler"} | select -First 1

  if ($TSMService)
  {
   Write-Host "TSM Scheduler Service found: $($TSMService.Name)"
    }
  else
  {
  Write-Host "TSM Scheduler Service not found"
  exit
  }

  try
  {

	Write-Host "Restarting service $($TSMService.Name)"

    $TSMService | Start-Service -Verbose -ErrorAction Stop

	Write-Host "Service $($TSMService.Name) started"
  
  }
  catch
  {
	  $ErrorText = $_.Exception.Message
		Write-Host "Error. $ErrorText" 
	  exit
  }

  $waitS = 0

  while ( !(Test-Path "$DSMSchedLogFilePath\$DSMSchedLogFileName") -and ($waitS -lt 5) )
	  { 
		$waitS++
	    Start-Sleep -Seconds 1
		write-host "File not found: $DSMSchedLogFilePath\$DSMSchedLogFileName, waiting 1 second. Try: $waitS"
	  }


  if ( !(Test-Path "$DSMSchedLogFilePath\$DSMSchedLogFileName") ) 

 {
 write-host "File not found: $DSMSchedLogFilePath\$DSMSchedLogFileName"
	 exit
  }

  Write-Host "File $DSMSchedLogFilePath\$DSMSchedLogFileName found."

   $waitS = 0

   while ( ( (Read-FileContent -path "$DSMSchedLogFilePath\$DSMSchedLogFileName").Length -lt 100  ) -and ($waitS -lt 5) )
	  { 
		$waitS++
	    Start-Sleep -Seconds 1
		write-host "File is too short, waiting 1 second. Try: $waitS"
	  }

 $DSMSchedLogFileContent  = Read-FileContent -path "$DSMSchedLogFilePath\$DSMSchedLogFileName"
 

if ($DSMSchedLogFileContent | select-string -pattern "Планировщик"  | select -last 1)
{
$LogFileLocale = "Russian"
}
elseif ($DSMSchedLogFileContent | select-string -pattern "Scheduler"  | select -last 1)
{
$LogFileLocale = "English"
}
else
{
$LogFileLocale = "Unknown"
}

Write-Host "Log file locale: $LogFileLocale"
